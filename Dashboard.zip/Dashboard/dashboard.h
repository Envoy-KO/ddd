#ifndef DASHBOARD_H
#define DASHBOARD_H

#include <QWidget>
#include <QWidget>
#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>
#include "car/car.h"
#include <QTimer>
#include <QDockWidget>
#include <QTextEdit>
#include <QGridLayout>
#include <QLCDNumber>
#include <QHBoxLayout>

class Dashboard: public QWidget
{
public:
    Dashboard(QWidget *parent = 0);
    ~Dashboard();

    QHBoxLayout *myDashboard;
    QLabel *label_BackGround;
     car  *mycar1;
     QLCDNumber *speed;
     car  *mycar2;
     QTimer testTimer;
public slots:
         void change_Speed(int Value1, int Value2);
};

#endif // DASHBOARD_H
