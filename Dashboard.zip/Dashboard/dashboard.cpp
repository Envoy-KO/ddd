#include "dashboard.h"


Dashboard::Dashboard(QWidget *parent)
    : QWidget(parent)
{
    this->resize (1254,300);
    this->setMinimumSize (1254,300);
    label_BackGround = new QLabel(this);
    label_BackGround->setGeometry (0,0,1920,1080);
    label_BackGround->setStyleSheet ("background-color:black");

    mycar1 = new car(this);
    mycar1->resize (400,255);
    mycar1->show ();

    speed = new QLCDNumber(this);
    mycar2 = new car(this);
    mycar2->resize (400,255);
    mycar2->show ();

    myDashboard = new QHBoxLayout;
    myDashboard->addWidget (mycar1);
    myDashboard->addWidget (speed);
    myDashboard->addWidget (mycar2);
    setLayout (myDashboard);

    connect(&testTimer,SIGNAL(timeout()),this,SLOT(change_Speed()));
    testTimer.start(100);
}

Dashboard::~Dashboard()
{

}

static float temp = 0.0;
void Dashboard::change_Speed(int Value1,int Value2)
{
    int int1,int2;
    if(Value1<0)
    {
        int1=-Value1;
    }
    else
    {
        int1=Value1;
    }

    if(Value2<0)
    {
        int2=-Value2;
    }
    else
    {
        int2=Value2;
    }
    if(int2>220)
    {
        int2=220;
    }
    if(int1>210)
    {
        int1=210;
    }
    mycar1->change_Speed(int2-10);
    mycar2->change_Speed(int1);
    speed->display (int2);
}
